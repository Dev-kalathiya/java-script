/**
you have to take the input  number stored in a variable with the name num
You have to print all the numbers from 1 to num, including num as well. in the console

Print each number on a new line

Sample Input 
5

Sample Output 1

1
2
3
4
5 */



let num=prompt("Enter a number:");
for(let i=1; i<=num; i++){
    console.log(i)
}